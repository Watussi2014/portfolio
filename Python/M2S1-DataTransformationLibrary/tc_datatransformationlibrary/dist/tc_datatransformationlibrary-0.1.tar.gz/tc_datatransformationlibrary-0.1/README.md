# Description

Python library for the Data Engineering course at Turing College.

The library provide 3 functions:

* transpose2d : Switch the axis of a 2d matrix.
* windows1d : Create windows from a 1d array.
* convolution2d: Apply a cross-correlation operation to a 2d array.